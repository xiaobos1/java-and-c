create
    definer = root@localhost procedure pro_test(IN a int, IN b int, OUT c int)
begin
	set c=a+b;
end;

